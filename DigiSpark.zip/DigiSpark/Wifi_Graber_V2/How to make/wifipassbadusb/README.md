# wifi-password-extractor
A Digispark rubber ducky script for Windows to Extract and Mail Wifi profiles (SSID, password) in plain text format.
